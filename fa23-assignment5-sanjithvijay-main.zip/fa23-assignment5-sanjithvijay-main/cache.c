#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#include "cache.h"
#include "jbod.h"

static cache_entry_t *cache = NULL;
static int cache_size = 0;
static int clock = 0;
static int num_queries = 0;
static int num_hits = 0;

int cache_create(int num_entries)
{
  if (cache_size != 0 || num_entries < 2 || num_entries > 4096)
  { // Check if the cache already exists or isn't in the proper bound//
    return -1;
  }
  cache = calloc(num_entries, sizeof(cache_entry_t)); // Allocate memory for the cache//
  cache_size = num_entries;                           // Set to num_entries//
  return 1;
}

int cache_destroy(void)
{
  if (cache_size == 0)
  { // Check if cache doesn't exist//
    return -1;
  }
  free(cache);    // Free allocated memory//
  cache = NULL;   // Set to NULL//
  cache_size = 0; // Reset to 0//
  return 1;
}

int cache_lookup(int disk_num, int block_num, uint8_t *buf)
{
  if (cache_size == 0 || buf == NULL)
  { // Check if cache is 0 or the buffer is null//
    return -1;
  }
  num_queries++; // Increment the number of queries//

  for (int i = 0; i < cache_size; i++)
  { // Iterate over cache//
    if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num)
    {                                               // Check if cache entry is valid and matches disk and block//
      memcpy(buf, cache[i].block, JBOD_BLOCK_SIZE); // Copies the block into buf//
      num_hits++;                                   // Increments the global variable//
      cache[i].clock_accesses = clock;              // Updates the access time, to indicate that the entry was accessed recently//
      return 1;
    }
  }
  return -1;
}

void cache_update(int disk_num, int block_num, const uint8_t *buf)
{
  for (int i = 0; i < cache_size; i++) // Iterate over cache//
  {
    if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num)
    {
      memcpy(cache[i].block, buf, JBOD_BLOCK_SIZE); // Update block with new data from buf//
      cache[i].clock_accesses = clock++;            // Update to access current clock value//
      break;                                        // Break loop once done//
    }
  }
}

int cache_insert(int disk_num, int block_num, const uint8_t *buf)
{
  // Check if buffer is NULL, cache size is 0, or invalid disk and block numbers
  if (buf == NULL || cache_size == 0 || disk_num < 0 || disk_num > 15 || block_num < 0 || block_num > 255)
  {
    return -1;
  }

  for (int i = 0; i < cache_size; i++)
  { // Check is entry already exits//
    if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num)
    {
      return -1;
    }
  }

  int mru_index = -1; // MRU entry index//
  int max_clock = -1; // Max clock access value//
  for (int i = 0; i < cache_size; i++)
  { // Find empty slot or entry//
    if (!cache[i].valid)
    {
      mru_index = i;
      break;
    }
    else if (cache[i].clock_accesses > max_clock)
    {
      // Update max_clock and mru_index//
      max_clock = cache[i].clock_accesses;
      mru_index = i;
    }
  }
  cache[mru_index].valid = true; // Entry is valid
  cache[mru_index].disk_num = disk_num;
  cache[mru_index].block_num = block_num;
  memcpy(cache[mru_index].block, buf, JBOD_BLOCK_SIZE); // Copy the data from buf to the cache block//
  cache[mru_index].clock_accesses = clock++;            // Update clock_accesses and increment the global clock//
  return 1;
}

bool cache_enabled(void)
{
  return false;
}

void cache_print_hit_rate(void)
{
  fprintf(stderr, "num_hits: %d, num_queries: %d\n", num_hits, num_queries);
  fprintf(stderr, "Hit rate: %5.1f%%\n", 100 * (float)num_hits / num_queries);
}

int cache_resize(int new_num_entries)
{
  if (new_num_entries < 2 || new_num_entries > 4096) // Check if it isn't in proper bounds//
  {
    return -1;
  }

  cache_entry_t *new_cache = calloc(new_num_entries, sizeof(cache_entry_t)); // Allocate new cache with specified size//
  if (new_cache == NULL)
    return -1;

  int min_size = new_num_entries < cache_size ? new_num_entries : cache_size; // Determine smaller size between new size and current cache size//
  for (int i = 0; i < min_size; i++)
  {
    if (cache[i].valid)
    {
      new_cache[i] = cache[i]; // Copy valid cache entry//
    }
  }

  // Free cache and update cache and size//
  free(cache);
  cache = new_cache;
  cache_size = new_num_entries;
  return 1;
}