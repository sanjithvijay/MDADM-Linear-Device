#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cache.h"
#include "jbod.h"
#include "mdadm.h"
#include "net.h"

int is_mounted = 0;
int is_written = 0;

static int mounted = 0; // Variable to determine whether the disk is mounted or not//

void translate(uint32_t address, int *diskid, int *blockid, int *offset) // Converts the linear address into a disk identifier, block identifier, and the offset within the block//
{
  *blockid = (address % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
  *diskid = (address / JBOD_DISK_SIZE);
  *offset = (address % JBOD_DISK_SIZE) % JBOD_BLOCK_SIZE;
}

uint32_t encode_operation(jbod_cmd_t command, int diskid, int blockid) // Makes sure the JBOD is stored as a 32 bit integer//
{
  uint32_t operation = 0x0;
  operation = command << 12 | diskid | blockid << 4; // Bits Size//
  return operation;
}

int mdadm_mount(void) // Mounts the linear device//
{
  if (mounted != 1)
  {
    uint32_t operation = encode_operation(JBOD_MOUNT, 0, 0);
    jbod_client_operation(operation, NULL);
    mounted = 1;
    return 1;
  }
  else
  {
    return -1;
  }
}

int mdadm_unmount(void) // Unmounts the linear device//
{
  if (mounted != 0)
  {
    uint32_t operation = encode_operation(JBOD_UNMOUNT, 0, 0);
    jbod_client_operation(operation, NULL);
    mounted = 0;
    return 1;
  }
  else
  {
    return -1;
  }
}

int seek(int diskid, int blockid) // Seeks to disk and block//
{
  int opseek_disk = encode_operation(JBOD_SEEK_TO_DISK, diskid, 0);
  int seek_disk = jbod_client_operation(opseek_disk, NULL);
  int opseek_block = encode_operation(JBOD_SEEK_TO_BLOCK, 0, blockid);
  int seek_block = jbod_client_operation(opseek_block, NULL);

  if (seek_block || seek_disk) // Error if failed//
  {
    return -1;
  }
  else
  {
    return 0;
  }
}

int mdadm_read(uint32_t start_addr, uint32_t read_len, uint8_t *read_buf) // Reads data from address//
{
  if (mounted != 0 && read_len <= 0x400 && start_addr >= 0 && start_addr + read_len <= 0x100000 && (read_buf != 0 || read_len == 0)) // Makes sure it is valid//
  {
    uint8_t temp_buf[JBOD_BLOCK_SIZE];
    int bytes_used = 0;
    int rest_of_bytes = read_len;
    int blockid;
    int diskid;
    int offset;

    while (rest_of_bytes > 0)
    {
      translate(start_addr + bytes_used, &diskid, &blockid, &offset);

      if (cache_lookup(diskid, blockid, temp_buf) == -1) // Cache miss//
      {
        seek(diskid, blockid);
        jbod_client_operation(encode_operation(JBOD_READ_BLOCK, 0, 0), temp_buf);
        cache_insert(diskid, blockid, temp_buf);
      }

      int bytes_to_copy = JBOD_BLOCK_SIZE - offset;

      if (bytes_to_copy > rest_of_bytes)
      {
        bytes_to_copy = rest_of_bytes;
      }

      memcpy(read_buf + bytes_used, offset + temp_buf, bytes_to_copy); // Copy the memory and sent to the temp buffer//

      bytes_used += bytes_to_copy;
      rest_of_bytes -= bytes_to_copy;
    }
    return read_len;
  }
  else
  {
    return -1;
  }
}

int mdadm_write_permission(void)
{
  uint32_t operation = encode_operation(JBOD_WRITE_PERMISSION, 0, 0); // Command to enable write permission//
  if (jbod_client_operation(operation, NULL) == 0)                    // Send the command to the JBOD system//
  {
    return 0;
  }
  return -1;
}

int mdadm_revoke_write_permission(void)
{
  uint32_t operation = encode_operation(JBOD_REVOKE_WRITE_PERMISSION, 0, 0); // Command to revoke write permission//
  if (jbod_client_operation(operation, NULL) == 0)                           // Send the command to the JBOD system//
  {
    return 0;
  }
  return -1;
}

int mdadm_write(uint32_t start_addr, uint32_t write_len, const uint8_t *write_buf)
{
  if (mounted != 0 && write_len <= 0x400 && start_addr >= 0 && start_addr + write_len <= 0x100000 && (write_buf != 0 || write_len == 0)) // Makes sure it is valid//
  {
    uint8_t temp_buf[JBOD_BLOCK_SIZE];
    int diskid;
    int blockid;
    int offset;
    int copy_of_bytes = write_len;
    int bytes_written = 0;
    int current_address = start_addr;

    while ((write_len + start_addr) > current_address)
    {
      translate(current_address, &diskid, &blockid, &offset); // Translate the linear address into diskid, blockid, and offset//

      seek(diskid, blockid); // Seek to the disk and block position for writing//

      if (cache_lookup(diskid, blockid, temp_buf) == -1) // Read block into temp_buf, either from cache or JBOD//
      {                                                  // Cache miss//
        jbod_client_operation(encode_operation(JBOD_READ_BLOCK, 0, 0), temp_buf);
        cache_insert(diskid, blockid, temp_buf);
      }

      int bytes_to_write = JBOD_BLOCK_SIZE - offset;
      if (bytes_to_write > copy_of_bytes)
      {
        bytes_to_write = copy_of_bytes;
      }

      memcpy(temp_buf + offset, write_buf + bytes_written, bytes_to_write);
      seek(diskid, blockid);
      jbod_client_operation(encode_operation(JBOD_WRITE_BLOCK, 0, 0), temp_buf);
      cache_update(diskid, blockid, temp_buf); // Update the cache with new data

      copy_of_bytes -= bytes_to_write;
      bytes_written += bytes_to_write;
      current_address += bytes_to_write;
    }
    return write_len; // Return the number of bytes written//
  }
  else
  {
    return -1; // Invalid Input//
  }
}
