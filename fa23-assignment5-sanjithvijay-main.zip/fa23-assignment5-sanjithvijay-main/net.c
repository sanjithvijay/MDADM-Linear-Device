#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <err.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include "net.h"
#include "jbod.h"

/* the client socket descriptor for the connection to the server */
int cli_sd = -1;

/* attempts to read n bytes from fd; returns true on success and false on
 * failure */
bool nread(int fd, int len, uint8_t *buf)
{
  int bytes_read = 0;
  while (bytes_read < len) // Keep reading until bytes are read//
  {
    int result = read(fd, &buf[bytes_read], len - bytes_read); // Read from fd into buf//
    if (result == -1)
    {
      return false;
    }
    bytes_read += result; // Increment by the number of bytes read//
  }
  return true;
}

/* attempts to write n bytes to fd; returns true on success and false on
 * failure */
bool nwrite(int fd, int len, uint8_t *buf) // Same logic as nread//
{
  int bytes_written = 0;
  while (bytes_written < len)
  {
    int result = write(fd, &buf[bytes_written], len - bytes_written);
    if (result == -1)
    {
      return false;
    }
    bytes_written += result;
  }
  return true;
}

/* attempts to receive a packet from fd; returns true on success and false on
 * failure */
bool recv_packet(int fd, uint32_t *op, uint16_t *ret, uint8_t *block)
{
  uint8_t packet[HEADER_LEN + JBOD_BLOCK_SIZE]; // Created buffer for packet//
  if (!nread(fd, HEADER_LEN, packet))           // Read packet header, return false if fails//
  {
    return false;
  }

  memcpy(op, packet, sizeof(*op));
  *op = ntohl(*op); // Convert op from network to host byte order//
  memcpy(ret, packet + sizeof(*op), sizeof(*ret));

  if (*ret & 0x02) // Check if data block exists//
  {
    if (!nread(fd, JBOD_BLOCK_SIZE, block)) // Read data block, return false if fails, else return true//
    {
      return false;
    }
  }
  return true;
}

/* attempts to send a packet to sd; returns true on success and false on
 * failure */
bool send_packet(int sd, uint32_t op, uint8_t *block)
{
  uint8_t packet[HEADER_LEN + JBOD_BLOCK_SIZE];
  uint16_t len = HEADER_LEN;
  uint8_t infocode = 0x00;
  uint32_t command = op >> 12 & 0x3f;

  if (command == JBOD_WRITE_BLOCK) // Check if command is write operations//
  {
    len += JBOD_BLOCK_SIZE;
    infocode = 0x02; // Infocode initiliazed as stated in ReadMe protocol//
  }

  op = htonl(op); // Convert op to network byte order//

  memcpy(packet, &op, sizeof(op));
  memcpy(packet + sizeof(op), &infocode, sizeof(infocode));

  if (len > HEADER_LEN) // Check if data block exists//
  {
    memcpy(packet + HEADER_LEN, block, JBOD_BLOCK_SIZE);
  }
  return nwrite(sd, len, packet); // Write packet to socket//
}

/* connect to server and set the global client variable to the socket */
bool jbod_connect(const char *ip, uint16_t port)
{
  struct sockaddr_in caddr;     // Socket address structure//
  caddr.sin_family = AF_INET;   // Address family//
  caddr.sin_port = htons(port); // Convert port number to network byte order//

  if (!inet_aton(ip, &caddr.sin_addr)) // Convert IP address to binary form//
  {
    return false;
  }

  cli_sd = socket(AF_INET, SOCK_STREAM, 0); // Create new socket//
  if (cli_sd == -1)
  {
    return false;
  }

  if (connect(cli_sd, (const struct sockaddr *)&caddr, sizeof(caddr)) == -1) // Concect to server//
  {
    close(cli_sd);
    cli_sd = -1;
    return false;
  }
  return true;
}

void jbod_disconnect(void) // Disconnect from server//
{
  if (cli_sd != -1)
  {
    close(cli_sd);
    cli_sd = -1;
  }
}

int jbod_client_operation(uint32_t op, uint8_t *block)
{
  uint16_t return_code;
  send_packet(cli_sd, op, block); // Send packet//
  uint32_t temp_op;
  recv_packet(cli_sd, &temp_op, &return_code, block); // Receive packet//

  if (op != temp_op) // Check if sent and received match//
  {
    return -1;
  }
  return return_code;
}